1. cv_code.cpp: all detection subsystem.
2. cvui.h: GUI: support lib
3.xPCUDPSock.h: UDP sender.
4. still needed: TIVA lib, OpenCV lib, PSEyeCamera lib.