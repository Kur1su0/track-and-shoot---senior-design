1. cv (folder) : codes for CV subsystem
2. tracknshoot.slx: Simulink file to be ran on Tiva
3. Circuit Design.pdf: Drawing of pinouts and connections
4. Laser Cutting.ai: Illustrator file for creating the structure